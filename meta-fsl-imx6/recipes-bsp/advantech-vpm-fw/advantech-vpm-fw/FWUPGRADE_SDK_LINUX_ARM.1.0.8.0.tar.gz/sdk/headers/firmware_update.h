#ifndef FIRMWARE_UPDATE_H
#define FIRMWARE_UPDATE_H

typedef unsigned long DWORD;
typedef unsigned char BYTE;
typedef unsigned long ULONG;

#if defined (WINCE) || defined (WIN32)

	#ifdef FWUPGRADE_DLL_EXPORTS
		#define SDK_DLLAPI __declspec( dllexport )
	#else
		#define SDK_DLLAPI __declspec( dllimport )
	#endif

#else

	#ifndef _stdcall
		#define _stdcall
	#endif

	#ifndef NULL
		#define NULL 0
	#endif

	#include <pthread.h>
	typedef struct _OSEVENT {pthread_cond_t *event_handle; pthread_mutex_t *mutex_handle;} OSEVENT;

	#define SDK_DLLAPI

#endif

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

#define FWUPGRADE_BOOTLOADERINFO_STRING_SIZE 15 
#define FWUPGRADE_VERSION_STRING_SIZE 8

#define FWUPGRADE_CHANNEL_COM	1
#define FWUPGRADE_CHANNEL_HID	2
#define FWUPGRADE_CHANNEL_I2C	4
#define FWUPGRADE_CHANNEL_CAN	8

//	Error code set of utility
#define ERR_UNKNOWN_NODE              (-9)
#define ERR_GET_INFORMATION_FAILED    (-8)
#define ERR_UPDATE_FAILED             (-7)
#define ERR_INVALID_EBFFILE           (-6)
#define ERR_OPEN_COMPORT_FAILED       (-5)
#define ERR_INVALID_ARG               (-4)
#define ERR_OUTOFMEMORY               (-3)
#define ERR_NOT_INITIALIZED           (-2)
#define ERR_INITIALIZED_ALREADY       (-1)

#define SUCCESS                       (0)
#define UNSUPPORTED                   (2)

typedef enum fwupgrade_type
{
	FWUPGRADE_TYPE_VPM = 0,
	FWUPGRADE_TYPE_CAN,
} fwupgrade_type;

typedef struct _fwupgrade_info{
	char bootloaderinfo[FWUPGRADE_BOOTLOADERINFO_STRING_SIZE];
	char firmwareversion[FWUPGRADE_VERSION_STRING_SIZE];
	char bootloaderversion[FWUPGRADE_VERSION_STRING_SIZE];
	BYTE checksumtag;
	BYTE userareaempty;
	BYTE downloadchannel;
}fwupgrade_info;

typedef struct _fwupgrade_config {
	unsigned int baud_rate;
	char node_path[32];
	int vid;
	int pid;
} fwupgrade_config;

SDK_DLLAPI int fwupgrade_init( const char *ebf_filepath );
SDK_DLLAPI int fwupgrade_init_ex( const char *ebf_filepath, fwupgrade_config *cfg);
SDK_DLLAPI int fwupgrade_deinit();
SDK_DLLAPI int fwupgrade_get_information( fwupgrade_info* info );
SDK_DLLAPI int fwupgrade_get_file_information(const char* ebf_filepath, fwupgrade_info* info );
SDK_DLLAPI int fwupgrade_upgrade();
SDK_DLLAPI int fwupgrade_get_progress( int* progress );

#ifdef __cplusplus
}
#endif

#endif
