#if defined (_WIN32)
	#pragma comment(lib, "fwupgrade.lib")

	#include "windows.h"
	#include <process.h>
#elif defined (__linux__)
	#ifndef NULL
		#define NULL 0
	#endif
	#include <pthread.h>
	#include <unistd.h>
#else
	#error:Unknown OS
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "firmware_update.h"

static int need_confirm = 1;
static char g_node_path[256] = {0};
static int g_baudrate = 0;
static int g_star_monitor = 0;
static int g_vid = 0;
static int g_pid = 0;

#if defined (_WIN32)
HANDLE progress_thread_handle = INVALID_HANDLE_VALUE;
#elif defined (__linux__) || defined (ANDROID)
pthread_t progress_thread_handle = 0;
#else
	#error:Unknown OS
#endif

#if defined (_WIN32)
unsigned int WINAPI fw_update_progress_monitor_process(void *p)
#elif defined (__linux__)
static void *fw_update_progress_monitor_process(void *p)
#else
	#error:Unknown OS
#endif
{
	int progress = 0;
	char bar[16];
	int curr_bar = 0;
	
	while(g_star_monitor)
	{
		fwupgrade_get_progress( &progress);
		
		// effect
		memset(bar, ' ', sizeof(bar));
		bar[curr_bar] = '>';
		bar[sizeof(bar)-1] = '\0';
		
		if( ++curr_bar == sizeof(bar))
			curr_bar = 0;

		printf("[%3d%%][%s]\r", progress, bar);
#if !defined (_WIN32)
		fflush(stdout);
#endif
	
#if defined (_WIN32)
		Sleep(500);
#elif defined (__linux__)
		usleep(500000);
#else
	#error:Unknown OS
#endif

	}

#if defined (_WIN32)
	_endthreadex( 0 );
#endif

	return 0;
}

void usage()
{
	printf("ebf-up <ebf-file-path> [-p node path] [-b baudrate] [-v hid vid] [-h hid pid] [-y]\r\n");
	printf("	<ebf-file-path>              .EBF file path\r\n");
	printf("	-p <node path> [Optional]    node path(e.g. vpm)\r\n");
	printf("	-b <baudrate>  [Optional]    baudrate(e.g. 460800)\r\n");
	printf("	-v <hid vid>   [Optional]    hid vid(e.g. 0x0483)\r\n");
	printf("	-h <hid pid>   [Optional]    hid pid(e.g. 0x576E)\r\n");
	printf("	-y             [Optional]    update without confirm\r\n");
}

int check_arg(int argc, char* argv[], char c)
{
	int ret = -1;
	char arg[4];
	sprintf(arg, "-%c", c);

	for(int i=1; i < argc; i++)
	{
		if( strcmp(argv[i], arg) == 0)
		{
			ret = 0;
			break;
		}
	}

	return ret;
}

int get_arg(int argc, char* argv[], char c, char *out)
{
	int ret = -1;
	int i = 1;
	char arg[4];
	sprintf(arg, "-%c", c);

	do
	{
		if( strcmp(argv[i], arg) == 0)
		{
			if( i+1 != argc )
			{
				if( argv[i+1][0] != '-')
				{
					strcpy(out, argv[i+1]);
					ret = 0;
					break;
				}
				else
				{
					return -2;
				}
			}
			else
			{
				return -2;
			}
		}

		i++;
	} while (i < argc) ;

	return ret;
}

int main(int argc, char* argv[])
{
	int ret;

	if( argc < 2)
	{
		usage();
		return -101;
	}

	int ext_flag = 0;

	if(!check_arg(argc, argv, 'y'))
		need_confirm = 0;

	ret = get_arg(argc, argv, 'p', g_node_path);
	if(ret == -2)
	{
		usage();
		return -101;
	}
	else if( ret == 0)
	{
		ext_flag = 1;
	}

	char str_baud[64];
	ret = get_arg(argc, argv, 'b', str_baud);
	if(ret == -2)
	{
		usage();
		return -101;
	}
	else if(ret == 0)
	{
		g_baudrate = atoi(str_baud);
		ext_flag = 1;
	}

	char str_vid[64];
	ret = get_arg(argc, argv, 'v', str_vid);
	if(ret == -2)
	{
		usage();
		return -101;
	}
	else if( ret == 0)
	{
		sscanf(str_vid, "%x", &g_vid);
		ext_flag = 1;
	}

	char str_pid[64];
	ret = get_arg(argc, argv, 'h', str_pid);
	if(ret == -2)
	{
		usage();
		return -101;
	}
	else if( ret == 0)
	{
		sscanf(str_pid, "%x", &g_pid);
		ext_flag = 1;
	}

	printf("fwupgrade..start\r\n");
	printf("check EBF file\r\n");

	if(!ext_flag)
	{
		if( ( ret=fwupgrade_init(argv[1]) ) != SUCCESS )
		{
			printf("fwupgrade_init fail = %d\r\n", ret);
			return ret;
		}
	}
	else
	{
		fwupgrade_config cfg;
		cfg.baud_rate = g_baudrate;
		sprintf(cfg.node_path, "%s", g_node_path); 
		cfg.vid = g_vid;
		cfg.pid = g_pid;

		if( ( ret=fwupgrade_init_ex(argv[1], &cfg) ) != SUCCESS )
		{
			printf("fwupgrade_init_ex fail = %d\r\n", ret);
			return ret;
		}
	}

	fwupgrade_info ebf_fw_info;

	if( ( ret=fwupgrade_get_file_information(argv[1], &ebf_fw_info) ) != SUCCESS )
	{
		printf("fwupgrade_get_file_information fail = %d\r\n", ret);
		return ret;
	}

	fwupgrade_info target_fw_info;
	memset(target_fw_info.bootloaderinfo, 0, FWUPGRADE_BOOTLOADERINFO_STRING_SIZE);
	memset(target_fw_info.firmwareversion, 0, FWUPGRADE_VERSION_STRING_SIZE );
	memset(target_fw_info.bootloaderversion, 0, FWUPGRADE_VERSION_STRING_SIZE );

	if( ( ret=fwupgrade_get_information(&target_fw_info) ) != SUCCESS )
	{
		printf("fwupgrade_get_information fail = %d\r\n", ret);
		//return ret;
	}

	printf("Target Platform:%s => %s\r\n", target_fw_info.bootloaderinfo, ebf_fw_info.bootloaderinfo);
	printf("Target Version:%s => %s\r\n", target_fw_info.firmwareversion, ebf_fw_info.firmwareversion);
	printf("Target bootloader version:%s\r\n", target_fw_info.bootloaderversion);
	printf("Target checksum tag :%02X\r\n", target_fw_info.checksumtag);
	printf("Target user area empty:%02X\r\n", target_fw_info.userareaempty);

	if(need_confirm)
	{
		printf("This proccess will update the target firmware. Are you sure?(Y/N)");
		char c;
		do
		{
			if( scanf("%c", &c) != 1)
				continue;

			if( c == 'y' || c == 'Y')
			{
				break;
			}
			else if( c == 'n' || c == 'N')
			{
				goto exit_prog;
			}

		} while (1) ; 
	}

	g_star_monitor = 1;
	
#if defined (_WIN32)
	unsigned thread_id;
	progress_thread_handle = (HANDLE) _beginthreadex(
	NULL,
	0,
	&fw_update_progress_monitor_process,
	NULL,
	0,
	&thread_id);
#elif defined (__linux__)
	pthread_attr_t thread_attr;
	pthread_attr_init(&thread_attr);
	pthread_create(&progress_thread_handle, &thread_attr, &fw_update_progress_monitor_process, NULL);
	pthread_attr_destroy(&thread_attr);
#endif
	

	printf("Please do not turn-off the power during the firmware upgrade process\r\n");
	printf("fwupgrade_upgrade..start\n");

	if( ( ret=fwupgrade_upgrade() ) != SUCCESS )
	{
		printf("fwupgrade_upgrade fail = %d\r\n", ret);
		goto exit_prog;
	}
	else
	{
		printf("fwupgrade_upgrade..complete\n");
	}

	g_star_monitor = 0;
	
#if defined (_WIN32)
	Sleep( 1000L ); // Wait Thread Close
	CloseHandle(progress_thread_handle);
#elif defined (__linux__)
	usleep( 1000000L ); // Wait Thread Close
	//pthread_join(progress_thread_handle, NULL);
#endif

exit_prog:
	if( ( ret=fwupgrade_deinit() ) != SUCCESS )
	{
		printf("fwupgrade_deinit fail = %d\r\n", ret);
		return ret;
	}
			
	return 0;
}

